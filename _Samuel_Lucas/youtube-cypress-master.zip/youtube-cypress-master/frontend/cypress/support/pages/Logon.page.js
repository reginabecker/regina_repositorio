module.exports = {
    INPUT_USER: 'input',
    BUTTON_LOGIN: '.button'
}