module.exports = {
    INPUT_NAME: "[data-cy=name]",
    INPUT_EMAIL: "[data-cy=email]",
    INPUT_WHATSAPP: "[data-cy=whatsapp]",
    INPUT_CITY: "[data-cy=city]",
    INPUT_UF: "[data-cy=uf]",
    BUTTON_SUBMIT: "[data-cy=submit]",
}