export const ELEMENTS = {
  name: '[data-cy=name]',
  email: '[data-cy=email]',
  whatsapp: '[data-cy=whatsapp]',
  city: '[data-cy=city]',
  uf: '[data-cy=uf]',
  submit: '[data-cy=submit]'
}