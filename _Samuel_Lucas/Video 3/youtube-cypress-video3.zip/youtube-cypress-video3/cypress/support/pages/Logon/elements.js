export const ELEMENTS = {
  id: '[data-cy=id]',
  submit: '[data-cy=button-login]'
}