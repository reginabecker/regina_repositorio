export const ELEMENTS = {
  logout: '[data-cy=button-logout]',
  newIncident: '[data-cy=button-new-incident]',
  delete: '[data-cy=button-delete]'
}