export const ELEMENTS = {
  title: '[data-cy=title]',
  description: '[data-cy=description]',
  value: '[data-cy=value]',
  submit: '[data-cy=button-save]'
}