import React from 'react';

import './global.css'
// JSX - javascript and xml
// import Logon from './pages/Logon';
import Routes from './routes';

function App() {
  return (
    <Routes />
  );
}

export default App;
